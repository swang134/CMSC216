#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>
#include <err.h>
#include <sysexits.h>
#include "safe-fork.h"
int main(void){
  pid_t pid;
  int pipefd[2];
  int count = 0;
  char *arg[] = {"wc","-w",NULL};
  pipe(pipefd);
  pid = safe_fork();
  if (pid > 0){
    dup2(pipefd[0], STDIN_FILENO);
    close(pipefd[0]);
    close(pipefd[1]);
    scanf("%d", &count);
    if(count < 200){
      printf("Too short!\n");
      exit(1);
    }else
      printf("Long enough!\n");
  }else if (pid == 0){
    dup2(pipefd[1], STDOUT_FILENO);
    execv("/usr/bin/wc", arg);
    close(pipefd[0]);
    close(pipefd[1]);
  }else{
    err(EX_OSERR, "Can't make new process");
  }
  return 0;
}
