#if !defined(MEMORY_CHECKING_H)
#define MEMORY_CHECKING_H

/* (c) Larry Herman, 2019.  You are allowed to use this code yourself, but
 * not to provide it to anyone else.
 */

void setup_memory_checking(void);
void check_heap(void);

#endif
