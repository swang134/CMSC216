#define FILE 0
#define DIR 1

/* Shuyao Wang 10/16/19 */

/* This header file will implement the unix structure */

/* Build basic structure - Node
 * a node will have a char pointer to store it's data
 * a int type to check this node is a file or directory
 * 3 node pointer to build link with other unix */
typedef struct node {
  char *data;
  struct node *next;
  int fileordir;
  struct node *child;
  struct node *parent;
}Node;

/* Implement struct List with 2 node pointer
 * root pointer points to root directory
 * curr pointer points to current directory */
typedef struct unix{
  Node *root;
  Node *curr;
  Node *path;
}Unix;
