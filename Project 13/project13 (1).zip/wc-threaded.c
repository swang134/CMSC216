#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <pthread.h>
#define THREAD_CT 1000

/* Counts the number of words, lines, and characters in the files whose
 * names are given as command-line arguments.  If there are no command-line
 * arguments then the line, word, and character counts will just be 0.
 * Mimics the effects of the UNIX "wc" utility, although does not have
 * exactly the same behavior in all cases.
 */
typedef struct count{
  int line;
  int word;
  int chars;
}Count;

 static void *count(void *ptr) {
  char ch, next_ch;
  int lines, words, chars, total_lines= 0, total_words= 0,
      total_chars= 0;
  Count *count = malloc(sizeof(*count));
  FILE *fp;

  /* note that we skip argv[0], the name of the program being run */
   /* for each command-line argument */
    fp= fopen(ptr, "r");  /* open that file */

    /* silently ignore any problems trying to open files */
    if (fp != NULL) {
      lines= words= chars= 0;

      /* read each file one character at a time, until EOF */
      ch= fgetc(fp);
      while (!feof(fp)) {
        next_ch= fgetc(fp);  /* look ahead and get the next character */
        ungetc(next_ch, fp);  /* unread the next character (see Chapter 15) */

        /* update the counts as needed every time a character is read */

        /* a newline means the line count increases */
        if (ch == '\n')
          lines++;

        /* if the current character is not whitespace but the next character
           is, or if the current character is not whitespace and it is the
           last character in the input, the word count increases */
        if (!isspace(ch) && (isspace(next_ch) || feof(fp)))
          words++;

        /* increasing the character count is a no-brainer */
        chars++;

        ch= fgetc(fp);
      }

      /* add the totals for the current file into the accumulating totals
         for all files */
      total_lines += lines;
      total_words += words;
      total_chars += chars;

      count->line = total_lines;
      count->word = total_words;
      count->chars = total_chars;
      fclose(fp);
    }

      return count;
 }

int main(int argc, char *argv[]) {
  pthread_t tids[THREAD_CT];
  int i;
  void *ptrs[THREAD_CT];
  Count *points; 
  char *filename;
int count_l = 0 , count_w = 0, count_c = 0;
  for (i= 0; i < argc-1; i++) {
    filename= argv[i+1];
    pthread_create(&tids[i], NULL, count, filename);
  }

  for (i= 0; i < argc-1; i++) {
    pthread_join(tids[i],&ptrs[i]);
    points = (Count *)ptrs[i];
    count_l += points->line;
    count_w += points-> word;
    count_c += points-> chars;
    free(points);
  }
  printf("%4d %4d %4d\n",count_l, count_w,
	   count_c);
  return 0;
 }
