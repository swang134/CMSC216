#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <err.h>
#include <string.h>
#include <sysexits.h>
#include "safe-fork.h"
#include "split.h"

/* Shuyao Wang 
 * ID 115935327
 * 11/20/19
 */

/* for this project, we will write a smaill simulation of a UNIX utility xargs
 * this simulation will have two mode, standard mode and line by line mode
 * the standard mode will read the file and put all the sentence in that file 
 * on to one line to execute, the line by line mode will read only one line in 
 * the file each time, and execute
 * if there are another arguement behind the xargs/xargs -i, the arguement will
 * also be executed
 */

#define MAX 999
int main(int argc, char *argv[]){
  char *pgm  = "/bin/echo"; 
  pid_t pid = safe_fork(); 
  char arr[MAX]= {'\0'}; /* initialize the arr */
  int count = 0;
  int argcount = 0;
  int status = 0;

  /* I start all my code in the child process to avoid the memory leak (there
   * is no way back after the child process done) */
  if (pid == 0){

    if (argc == 1){ /* standard mode with only one arguement */
      strcat(arr, "echo "); /* append the program name after it */
      count = strlen(arr);
      
      while (!feof(stdin)) { /* scan characters on file into arr */
	 scanf("%c", &arr[count]);
	 
	 if (arr[count] == '\n') /* if meet new line character -> change it to 
				  * space */
	   arr[count] = ' ';
	 count++;
       }
      execv(pgm,split(arr)); /* exec the program */
      exit(1); /* if fail exit with 1 */
    
    }else if (argc >= 2){ /* standard mode with multi arguement */
       
       if (strcmp(argv[1], "-i") != 0){ /* situation: standard mode with multi
					 * arguement after xargs */
	 count = 1;
	 while (count < argc) { /* append the rest arguement to the arr */
	   strcat (arr, argv[count]);
	   strcat(arr, " ");
	   count ++;
	 }
	 count = strlen(arr);
	 
	 while (!feof(stdin)) { /* scan all characters into arr until end of 
				 * file */
	   scanf("%c", &arr[count]);
	 
	   if (arr[count] == '\n') /* if new line char -> replace it to space */
	     arr[count] = ' ';
	   count++;
	 }

	 arr[count] = '\n'; /* change to new line char in the end of file */
	 execvp(argv[1],split(arr)); /* execute all the arguement with multi 
				      * arguement */
	 exit(1); /* if failed, exit with 1 */
	 
       } else { /* line by line mode */
	 
	 if (argc == 2) { /* line by line mode with only 2 arguement*/
	   strcat(arr, "echo "); /* add program name to arr */
	   count = 5;
	   
	   while (!feof(stdin)) { /* scan characters until the file end */
	     scanf("%c", &arr[count]);
	     
	     if (arr[count] != '\n')
		 count++;
	     
	     else{ /* if it is end of the line -> exec the program */
		 if (arr[count] == '\n' && !feof(stdin)) {
		   
		   if (!safe_fork()) { /* create chlid process to execute each 
				        * line */
		    execv(pgm, split(arr));
		    exit(1);
		   }
		   
		   count = 5; /* reset the count value */
		   wait(&status);
		   
		   if (status != 0) /* if the status is not 0, exit as 1 */
		     exit(1);
		 }
	     }
	   }

	 } else { /* line by line mode with multi arguement */
	   count = 2;
	   
	   while (count < argc) { /* append the rest arguement to the arr */
	     strcat (arr, argv[count]);
	     strcat(arr, " ");
	     count ++;
	   }
	   
	   count = strlen(arr);
	   argcount = strlen(arr); /* store arguement name */
	   
	   while (!feof(stdin)) { /* scan characters until the file end */
	     scanf("%c", &arr[count]);
	     
	     if (arr[count] != '\n')
		 count++;
	     
	     else { /* if meet the new line -> exec the program */
		 if (arr[count] == '\n' && !feof(stdin)) {
		   
		   if (!safe_fork()) { /* creat a new child process to exect
					* the line */
		     execvp(argv[2],split(arr)); /* exec line */
		     exit(1); /* if failed , exit with 1 */
		   }
		   
		   count = argcount; /* reset the count */
		   wait(&status);
		   
		   if (status != 0) /* if status is not 0 exit with 1 */
		     exit(1);
		 }
	     }
	   }
	 }
       }
     }
   }
   wait(&status);
   
   if (status != 0) /* if status is not 0 exit with 1 */
       exit(1);
     return 0;
}
