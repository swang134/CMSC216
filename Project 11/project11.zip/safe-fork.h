#if !defined(SAFE_FORK_H)
#define SAFE_FORK_H

/* (c) Larry Herman, 2017.  You are allowed to use this code yourself, but
 * not to provide it to anyone else.
 */

int safe_fork(void);

#endif
