#include "student.h"
#include <stdlib.h>
#include <string.h>

Student *new_student(const char name[], unsigned int id, float shoe_size){
  Student *student= malloc(sizeof(Student));
  if(name==NULL){
    student->name = malloc(1);
    strcpy(student->name, "");
  } else{
    student->name= malloc(strlen(name));
    strcpy(student->name , name);
  }
  student->id = id;
  student->shoe_size = shoe_size;
  return student;
}
unsigned int has_id(Student *const student, unsigned int id){
 if(student == NULL)
    return 0;
  return student->id == id;
}
unsigned int has_name(Student *const student, const char name[]){
  if(name == NULL || student == NULL)
    return 0;
  return strcmp(student->name, name)==0;
}
unsigned int get_id(Student *const student){
  if(student == NULL)
    return 0;
  return student->id;
}
float get_shoe_size(Student *const student){
  if(student == NULL)
    return 0.0;
  return student->shoe_size;
}
void change_shoe_size(Student *const student, float new_shoe_size){
  if(student != NULL)
    student->shoe_size = new_shoe_size;
}
void change_name(Student *const student, const char new_name[]){
  if(student != NULL){
    if(new_name==NULL){
      student->name = malloc(1);
      strcpy(student->name, "");
    }else{
      student->name= malloc(strlen(new_name));
      strcpy(student->name , new_name);
    }
  }
}
void copy_student(Student *student1, Student *const student2){
  if(student1 != NULL && student2 !=NULL){
    student1->name= malloc(strlen(student2->name));
    strcpy(student1->name , student2->name);
    student1->id = student2->id;
    student1->shoe_size = student2->shoe_size;
  }
}
