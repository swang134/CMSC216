#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "unix.h"

/* Shuyao Wang 
 * 115935327
 * 10/29/10 */

/* this project are required to build a small simulation of the UNIX system
 * In this project we can modigy the Unix parameter or product output
 * we will add files and directories to current directories 
 * we print it out the directories by use ls 
 * one directories may have zero or more subdirectory, and cd can make other 
 * directory to current directory
 */

/* this function is to initilizing a filesystm
 * creat root dirctory */
void mkfs(Unix *filesystem){

  /* if the parameter is NULL, the function will have no effect */
  if( filesystem != NULL ){

    /* creat a pointer that have size of Node */
    Node *replace = malloc(sizeof(*replace));

    /* check whether the memory is successful allocated */
    if( replace != NULL ){

      /* because there is only one nodeso both root and curr will points to
       * that node */
      filesystem->root = replace;

      /* initilize the root directory */
      filesystem->curr = filesystem->root;
      filesystem->root->child = NULL;
      filesystem->root->parent = NULL;
      filesystem->root->next = NULL;
      filesystem->root->fileordir = 1;
    }
  }
}

/* this function is create a file, if it does not already exist and add it as
 * a child to current directory */
int touch(Unix *filesystem, const char arg[]){
  int a = 0;
  Node *prev = NULL, *currt, *new_node;

  /* if parameter is NULL = function have no effect */
    if( filesystem != NULL && arg != NULL ){

      /* if arg is empty or equals to "." or ".." or "/" the function 
       * will have no effect */
      if( strstr(arg, "/") == NULL && strcmp(arg, "..") != 0 &&
	 strcmp(arg, ".") != 0 && strcmp(arg, "") != 0 ){

	/* make currt the first node of the current directory */
	currt = filesystem->curr->child;

	/* go though all the node check whether the name alreay exist */
	while( currt != NULL ){
	  /* if the name already exist -> error */
	  if( strcmp(currt->data, arg) == 0 )
	    return 0;
	  else{
	    prev = currt;
	    currt = currt->next;
	  }
	}

	/* creat new node with size of node */
	  new_node = malloc(sizeof(*new_node));	  
	  if(new_node != NULL){

	    /* initilize the node */
	    new_node->data = malloc(sizeof(arg));
	    strcpy(new_node->data, arg);
	    new_node->parent = filesystem->curr;
	    new_node->child = NULL;
	    new_node->next = NULL;
	    new_node->fileordir = 0;

	    /* if this directory have no child, make new node as its first
	     * node */
	    if( prev == NULL )
	      filesystem->curr->child = new_node;

	    else {
	    	currt = filesystem->curr->child;
		/* put the newnode into list as increase order*/
		while( currt != NULL &&  strcmp(currt->data, arg) < 0 ){
		   prev = currt;
		   currt = currt->next;
		}

		/* if the name < first node's name -> make new node as first
		 * child of current directory */
		if( currt == filesystem->curr-> child ){
		  new_node->next = currt;
		  filesystem->curr->child = new_node;
		}else{
		  prev->next = new_node;
		  new_node->next = currt;
		}
	    }
	    a = 1;
	}
       /* if arg == . or .. or / -> not error case*/
      } else if( strcmp(arg, "/") == 0 || strcmp(arg, "..") == 0 ||
	 strcmp(arg, ".") == 0 )
	a = 1;
    }
    return a;
}

/* this function is to create a subdirectory in the current directory if it is 
 * not exist */
int mkdir(Unix *filesystem, const char arg[]){
 int a = 0;
  Node *prev = NULL, *currt, *new_node;
  
  /* if paramenter is NULL -> function have no effect */
    if( filesystem != NULL && arg != NULL ){
      
      /* if arg is empty or equals to "." or ".." or "/" the function 
       * will have no effect -> error case  */
      if( strstr(arg, "/") == NULL && strcmp(arg, "..") != 0 &&
	 strcmp(arg, ".") != 0 && strcmp(arg, "") != 0 ){
	currt = filesystem->curr->child;

	/* check whether name exist */
	while( currt != NULL ){
	  if( strcmp(currt->data, arg) == 0 )
	    return 0;
	  else{
	    prev = currt;
	    currt = currt->next;
	  }
	}

	/* create and initilize new node */
	  new_node = malloc(sizeof(*new_node));	  
	  if( new_node != NULL ){
	    new_node->data = malloc(sizeof(arg));
	    strcpy(new_node->data, arg);
	    new_node->parent = filesystem->curr;
	    new_node->child = NULL;
	    new_node->next = NULL;
	    new_node->fileordir = 1;

	    /* if no subnode in current -> make new node as first child */
	    if( prev == NULL )
	      filesystem->curr->child = new_node;
	    else {

	      /* sort the list */
	    	currt = filesystem->curr->child;
		while( currt != NULL &&  strcmp(currt->data, arg) < 0 ){
		   prev = currt;
		   currt = currt->next;
		}

		/* if newnode->data < firstchild-> data, make newnode as first*/
		if( currt == filesystem->curr-> child ){
		  new_node->next = currt;
		  filesystem->curr->child = new_node;
		}else{
		  prev->next = new_node;
		  new_node->next = currt;
		}
	    }
	    a = 1;
	}
      }
    }
    return a;
}

/* this function is to change the current direcotry of is Unix parameter 
 * if arg is the name of an immediate subdiectory of curr, curr = that subdir
 * if arg = . or ""  no effect 
 * if arg = .. change curr to its parent, no effect if curr is root
 * if arg = / change curr to root */
int cd(Unix *filesystem, const char arg[]){
  int a = 0;
  Node *currt;

  /* if parameter is NULL -> no effect */
    if( filesystem != NULL && arg != NULL ){

      /* if the arg is the name of directory which is impossible to be . or 
       * .. or / or "" */
       if( strstr(arg, "/") == NULL && strcmp(arg, "..") != 0 &&
	 strcmp(arg, ".") != 0 && strcmp(arg, "") != 0 ){
	currt = filesystem->curr->child;

	/* error case: if there is no exist name or the exist name is a file */
	while( currt != NULL ){
	  if( strcmp(currt->data, arg)==0 && currt->fileordir == 1 ){
	    filesystem->curr = currt;
	    a = 1;
	  }
	  currt = currt->next;
	}

	/* case arg = . change curr to its parent */
      } else if( strcmp(arg, "..") == 0 ){

	 /* if curr is root -> no effect */
	if( filesystem->curr != filesystem->root )
	  filesystem->curr = filesystem->curr->parent;
	a = 1;

	/* case arg = /, change curr to root */
      } else if( strcmp(arg, "/") == 0 ){
	filesystem->curr = filesystem->root;
	a = 1;

	/* case arg = "" or ., no effect */
       } else if( strcmp(arg, ".") == 0 || strcmp(arg, "") ==0 ){
	filesystem->curr = filesystem->curr;
	a = 1;
      }
    }
    return a;
}

/* this function is to list the files and subdirectories of current dircetory 
 * or the file and subdirectories of its argument or to list just its arguement
 * if that is a file */
int ls(Unix *filesystem, const char arg[]){
   int a = 0;
   Node *currt, *temp;

   /* if parameter is NULL -> no effect */
    if( filesystem != NULL && arg != NULL ){

      /* case: arg is exist name */
       if( strstr(arg, "/") == NULL && strcmp(arg, "..") != 0 &&
	 strcmp(arg, ".") != 0 && strcmp(arg, "") != 0 ){
	currt = filesystem->curr->child;

	/* if no such name -> error */
	while( currt != NULL ){
	  if( strcmp(currt->data, arg)==0 ){

	    /* if is the name of file then print the single name of that file */
	    if( currt->fileordir == 0 ){
	      printf("%s\n", currt->data);

	    /* if is the name of subdirecotries then print the subdirectories 
	     * and files of that subdirectores */
	    }else{
	      temp = currt->child;
	      while( temp != NULL ){

		/* case arg is file */
		 if( temp->fileordir == 0 )
		   printf("%s\n",temp->data);

		 /* case arg is directory */
		 else
		   printf("%s%c\n",temp->data,'/');
		temp = temp->next;
	      }
	    }
	    a = 1;
	  }
	  currt = currt->next;
	}
      } else {

	 /* arg = .. then print all of the files and subdirectories in the 
	  * parent of current directory */
	if(strcmp( arg, "..") == 0 ){
	  if( filesystem->curr != filesystem->root )
	    currt= filesystem->curr->parent->child;

	  /* if curr = root -> same effect if the arguement is . */
	  else
	    currt = filesystem->curr->child;

	  /* arg = / then print all of the files and subdirectories in the 
	   * root directory */
        } else if( strcmp(arg, "/") == 0 )
	   currt = filesystem->root->child;

	/* arg = "" or . then print all of files and subdirectories in the 
	 * current directory */
        else if ( strcmp(arg, ".") == 0 || strcmp(arg, "") == 0 )
	   currt = filesystem->curr->child;
	
        while( currt != NULL ){
	  
	  /* case arg is file */
	  if(currt->fileordir == 0)
	    printf("%s\n",currt->data);

	  /* case arg is directory */
	  else
	    printf("%s%c\n",currt->data,'/');
	  currt = currt->next;
	}
        a = 1;
      }
    }
    return a;
}

/* this function will print the name of current direcotry */
void pwd(Unix *filesystem){
  if( filesystem != NULL ){

    /* if the curr = root then only print a /*/
    if( filesystem->curr == filesystem->root )
      printf("%c\n", '/');
    else
      printf("%s\n", filesystem->curr->data);
  }
}
