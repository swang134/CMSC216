#include <stdio.h>
#include "unix.h"


/* CMSC 216, Fall 2019, Project #8
 * Public test 10 (public10.c)
 *
 * Tests creating a larger filesystem with various files and directories,
 * and calls all of the functions on it.
 *
 * Link this example with the driver object file driver.o, and run the
 * executable with input redirected from public10.input.  (Hint: you used
 * input redirection to run every test in Project #2.)  (Hint #2: Makefile
 * rules for this test will be different than for the other ones.)
 *
 * (c) Larry Herman, 2019.  You are allowed to use this code yourself, but
 * not to provide it to anyone else.
 */

int main() {
  Unix filesystem;

  mkfs(&filesystem);
  
  mkdir(&filesystem,"b");
  touch(&filesystem,".");
  mkdir(&filesystem,"/");
  touch(&filesystem, "");
  mkdir(&filesystem,"..");
  touch(&filesystem,"a");
  mkdir(&filesystem,"c");
  mkdir(&filesystem,"c");
  mkdir(&filesystem,"d");
  ls(&filesystem, ".");
  cd(&filesystem, "b");
  mkdir(&filesystem, "e");
  cd(&filesystem, "..");
  ls(&filesystem, "b");
  ls(&filesystem, "a");

  /*mkdir(&filesystem,"kangroo");
  touch(&filesystem,"pear");
  mkdir(&filesystem,"platypus");
  touch(&filesystem,"papaya");
  touch(&filesystem, "orange");

  cd(&filesystem, "kangroo");

  touch(&filesystem, "kiwi");
  mkdir(&filesystem, "papaya");
  mkdir(&filesystem, "pear");
  touch(&filesystem, "orange");

  cd(&filesystem, "..");
  cd(&filesystem, "platypus");

  touch(&filesystem, "apple");
  mkdir(&filesystem, "grape");
  mkdir(&filesystem, "banana");
  touch(&filesystem, "cherry");

  mkdir(&filesystem, "blue");
  touch(&filesystem, "green");
  mkdir(&filesystem, "purple");
  touch(&filesystem, "yellow");
  touch(&filesystem, "white");
  mkdir(&filesystem, "red");

  cd(&filesystem, "red");

  pwd(&filesystem);

  cd(&filesystem, "..");
  pwd(&filesystem);
  ls(&filesystem, ".");

  cd(&filesystem,"..");
  pwd(&filesystem);
  ls(&filesystem, ".");

  cd(&filesystem,"..");
  pwd(&filesystem);
  ls(&filesystem, ".");

  ls(&filesystem, "kangroo");*/

  return 0;
}
