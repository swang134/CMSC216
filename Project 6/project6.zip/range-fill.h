/* (c) Larry Herman, 2019.  You are allowed to use this code yourself, but
 * not to provide it to anyone else.
 */

void range_fill(int arr[][5], int x1, int y1, int x2, int y2, int value);
