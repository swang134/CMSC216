#include <stdio.h>
#include <assert.h>
#include "list.h"


int main(void) {
  List list;

  init(&list);
  assert(size(&list)==0);
  print(&list);
  prepend(&list, 1);
  print(&list);
  init(&list);
  append(&list, 0);
  append(&list, 1);
  append(&list, 2);
  append(&list, 3);
  append(&list, 4);
  append(&list, 5);
  append(&list, 6);
  append(&list, 7);
  append(&list, 8);
  append(NULL, 9);

  assert(size(&list) == 9);

  delete(&list, 0);

  assert(find(&list, 0) == -1);
  delete(&list, 8);
  assert(size(&list) == 8);
  prepend(&list, 9);
  print(&list);
  delete(&list, 8);

  print(&list);
  delete(&list, 1);
  delete(NULL,2);
  prepend(NULL,3);
  print(NULL);
  assert(size(NULL) == 0);
  assert(find(NULL,1) == 0);
  print(&list);
  init(&list);
  print(&list);
  append(&list,2);
  append(&list,1);
  append(&list,2);
  prepend(NULL,3);
  assert(find(&list,2)==0);
  delete(&list, 0);
  print(&list);
  printf("\nAll assertions experienced a favorable outcome!\n");

  return 0;
}
