#include <stdio.h>
#include <stdlib.h>
#include "list.h"

/* Shuyao Wang 
 * ID# 115935327
 * 10/16/19
 */

/* This project is to build a simple linked list, storing integers in C */

/* This function will initialize its List parameter to empty linked list
 * containing no elements */
void init(List *const list){

  /* if the parameter is NULL the function should have no effect */
  if(list != NULL)
    list->head = NULL;
}

/* This function is to add the integer new_value as a new element at the end
 * of its parameter lined list and return 1 */
int append(List *const list, int new_value){

  /* return 0 if parameter is NULL */
  if(list == NULL){
    return 0;
  }else{
    Node *curr = list-> head, *prev = NULL, *new_node = NULL;
    int result = 0;

    /* Find the last Node in linked list and set it as prev */
    while (curr!= NULL){
      prev = curr;
      curr = curr->next;
    }

    /* Create a new node with size of node */
    new_node = malloc(sizeof(*new_node));

    /* Make sure the malloc work correctly then initialize the node */
    if(new_node != NULL){
      new_node->data = new_value;
      new_node->next = NULL;

      /* If head is NULL then set the new node to head */
      if(prev == NULL)
	list->head = new_node;

      /* Add new node to end of linked list */
      else prev->next = new_node;
      result = 1;
    }
    return result;
  }
}

/* This function should add a new node as the new first element at the 
 * beginning of its parameter list */
int prepend(List *const list, int new_value){

  /* Return 0 if parameter is NULL */
   if(list == NULL){
    return 0;
  }else{
     Node *curr = list-> head, *new_node = NULL;
     int result = 0;

     /* Create a new node with size of node */
     new_node = malloc(sizeof(*new_node));

     /* Make sure the malloc work correctly then initialize the node */
     if(new_node != NULL){
       new_node->data = new_value;
       new_node->next = curr;

       /* change the new node as the first element of the linked list */
       list->head = new_node;
       result = 1;
     }
     return result;
   }
}

/* This function should return the number of elements being stored in 
 * its parameter list */
int size(List *const list){

  /* Return 0 if parameter is NULL */
   if(list == NULL){
    return 0;
   }else{
     Node *curr = list-> head;
     int result = 0;

     /* Count the number of node by go though all the node */
     while (curr!= NULL){
       curr = curr->next;
       result++;
     }
     return result;
   }
}

/* Find the occurence of value as an element of its parameter list and return
 * it index, if value is not present in the list, then return -1 
 * If occurence more than once return the first occurence */
int find(List *const list, int value){

  /* Return 0 if parameter is NULL */
   if(list == NULL){
    return 0;
  }else{
     Node *curr = list-> head;
     int count = 0;
     int result = -1;

     /* Find the occurence of value by go thoguh all the node */
     while (curr!= NULL){

       /* Directly return the position it first occur */
       if(curr->data == value)
	 return count;
       curr = curr->next;
       count++;
     }
     return result;
   }
}

/* This function should remove the element in its parameter list that is at 
 * index or position position and return 1
 * Free all dynamically allocated memory when it no longer needed 
 * Return 0 if position is not valid index */
int delete(List *const list, unsigned int position){

  /* Return 0 if parameter is NULL or position is not valid */
  if(position >= size(list) || list == NULL)
    return 0;
  else{
    Node *curr = list-> head, *prev = NULL;
    int count = 0;

    /* Set prev to the node that one before the node at position 
     * Set curr to the node at position */
    while (curr!= NULL && count < position){
      prev = curr;
      curr = curr->next;
      count++;
    }

    /* If delect the first element, directly set the head to second element */
    if(position==0 && count==0)
      list->head = curr->next;
    
    /* Remove the element at position */
    else
      prev->next = curr->next;

    /* Free the dynamically allocated memory when it no longer needed */
    free (curr);
    return 1;
  }
}

/* This function should print all elements of its parameter list, on same line
 * No blank space before first element or after last element  
 * No effect if list is empty
 * New line after print last element */
void print(List *const list){

  /* No effect is parameter is NULL */
  if(list != NULL){
    Node *curr = list-> head;

    /* No effect if list is empty 
     * Print all element in list if it is not empty */
    while (curr!= NULL){

      /* No space before first element */
      if(curr == list->head)
	printf("%d", curr->data);
      else
	printf(" %d", curr->data);

      /* New line after print last element */
      if(curr->next == NULL)
	printf("%c",'\n');
      curr = curr->next;
    }
  }
}
