int sum_of_cubes(int n);
int quadrant(int x, int y);
int num_occurrences_of_digit(long num, int digit);
